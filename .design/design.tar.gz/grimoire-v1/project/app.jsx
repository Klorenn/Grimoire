/* eslint-disable */

function App() {
  useReveal();
  return (
    <main>
      <Navbar />
      <Hero />
      <Problem />
      <Solution />
      <Features />
      <Science />
      <Testimonials />
      <Pricing />
      <Footer />
    </main>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
