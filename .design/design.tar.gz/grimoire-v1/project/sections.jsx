/* eslint-disable */
const { useState, useEffect, useRef, useMemo } = React;

/* ── Hooks ────────────────────────────────────────────────────── */
function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setReduced(mq.matches);
    update();
    mq.addEventListener?.('change', update);
    return () => mq.removeEventListener?.('change', update);
  }, []);
  return reduced;
}

/* simple intersection-observer reveal — adds .in once visible */
function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll('.reveal, .reveal-word');
    if (!('IntersectionObserver' in window)) {
      els.forEach((el) => el.classList.add('in'));
      return;
    }
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in');
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '-60px 0px -60px 0px' }
    );
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  });
}

/* ── Hero Video (ping-pong loop) ─────────────────────────────── */
function HeroVideo() {
  const videoRef = useRef(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const video = videoRef.current;
    if (!video || reduced) return;

    let direction = 1;
    let rafId;
    let lastTime = performance.now();

    const step = (now) => {
      const dt = (now - lastTime) / 1000;
      lastTime = now;
      if (direction === 1) {
        if (video.duration && video.currentTime >= video.duration - 0.05) {
          direction = -1;
          video.pause();
        }
      } else {
        video.currentTime = Math.max(0, video.currentTime - dt);
        if (video.currentTime <= 0.05) {
          direction = 1;
          video.play().catch(() => {});
        }
      }
      rafId = requestAnimationFrame(step);
    };

    video.muted = true;
    video.playsInline = true;
    const start = () => {
      video.play().catch(() => {});
      rafId = requestAnimationFrame(step);
    };
    if (video.readyState >= 2) start();
    else video.addEventListener('loadeddata', start, { once: true });

    return () => cancelAnimationFrame(rafId);
  }, [reduced]);

  return (
    <video
      ref={videoRef}
      src="assets/transition.mp4"
      poster="assets/frame-initial.png"
      muted
      playsInline
      preload="auto"
      className="absolute inset-0 w-full h-full object-cover z-0"
    />
  );
}

/* ── Ambient particles + atmospheric motion for hero ─────────── */
function HeroAmbient() {
  const reduced = usePrefersReducedMotion();

  const drifting = useMemo(() => {
    const glyphs = ['✦', '❋', '❀', '⊹', '✦', '⊹', '·'];
    return Array.from({ length: 22 }).map((_, i) => ({
      ch: glyphs[i % glyphs.length],
      left: Math.random() * 100,
      dx: (Math.random() - 0.5) * 200,
      rot: (Math.random() - 0.5) * 90,
      dur: 22 + Math.random() * 22,
      delay: -Math.random() * 40,
      size: 12 + Math.random() * 24,
    }));
  }, []);

  // wandering particles — more freeform paths
  const wanderers = useMemo(() => {
    const glyphs = ['✦', '⊹', '·', '✦'];
    return Array.from({ length: 10 }).map((_, i) => ({
      ch: glyphs[i % glyphs.length],
      left: Math.random() * 100,
      top: 30 + Math.random() * 70,
      dx: (Math.random() - 0.5) * 240,
      dy: -(40 + Math.random() * 50),
      dy2: -(80 + Math.random() * 40),
      s: 0.7 + Math.random() * 0.9,
      dur: 30 + Math.random() * 20,
      delay: -Math.random() * 40,
      size: 10 + Math.random() * 18,
      maxOp: 0.45 + Math.random() * 0.3,
    }));
  }, []);

  // soft atmospheric orbs — slow breath/drift
  const orbs = useMemo(() => ([
    { left: '12%', top: '24%', w: 320, h: 320, dur: 16, delay: -2,
      bg: 'radial-gradient(circle, rgba(255,232,168,0.55), rgba(232,168,71,0) 70%)' },
    { left: '64%', top: '12%', w: 460, h: 460, dur: 22, delay: -7,
      bg: 'radial-gradient(circle, rgba(168,208,216,0.6), rgba(168,208,216,0) 70%)' },
    { left: '78%', top: '58%', w: 280, h: 280, dur: 18, delay: -4,
      bg: 'radial-gradient(circle, rgba(255,232,168,0.45), rgba(232,168,71,0) 70%)' },
    { left: '32%', top: '70%', w: 360, h: 360, dur: 20, delay: -10,
      bg: 'radial-gradient(circle, rgba(244,229,194,0.5), rgba(244,229,194,0) 70%)' },
  ]), []);

  // long cloud wisps drifting across
  const wisps = useMemo(() => ([
    { top: '28%',  h: 60,  w: '38%', dur: 55, delay: -10, ny: '-2%',
      bg: 'linear-gradient(90deg, transparent, rgba(255,248,232,0.45), transparent)' },
    { top: '54%',  h: 80,  w: '46%', dur: 70, delay: -30, ny: '-4%',
      bg: 'linear-gradient(90deg, transparent, rgba(255,248,232,0.35), transparent)' },
    { top: '76%',  h: 50,  w: '32%', dur: 60, delay: -5,  ny: '-1%',
      bg: 'linear-gradient(90deg, transparent, rgba(244,229,194,0.4), transparent)' },
  ]), []);

  if (reduced) return null;

  return (
    <>
      {/* Soft orbs — beneath particles, above video */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-[2]" aria-hidden="true">
        {orbs.map((o, i) => (
          <span
            key={i}
            className="hero-orb"
            style={{
              left: o.left, top: o.top, width: o.w, height: o.h,
              background: o.bg,
              '--dur': `${o.dur}s`, '--delay': `${o.delay}s`,
              '--ox': `${(i % 2 ? 1 : -1) * 20}px`,
              '--oy': `${(i % 3 - 1) * 10}px`,
            }}
          />
        ))}
        {wisps.map((w, i) => (
          <span
            key={`w-${i}`}
            className="wisp"
            style={{
              top: w.top, height: w.h, width: w.w, background: w.bg,
              '--dur': `${w.dur}s`, '--delay': `${w.delay}s`, '--ny': w.ny,
            }}
          />
        ))}
      </div>

      {/* Drifting glyphs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-[3]" aria-hidden="true">
        {drifting.map((p, i) => (
          <span
            key={i}
            className="particle"
            style={{
              left: `${p.left}%`,
              fontSize: `${p.size}px`,
              '--dx': `${p.dx}px`,
              '--rot': `${p.rot}deg`,
              '--dur': `${p.dur}s`,
              '--delay': `${p.delay}s`,
            }}
          >
            {p.ch}
          </span>
        ))}
        {wanderers.map((p, i) => (
          <span
            key={`w-${i}`}
            className="particle-wander"
            style={{
              left: `${p.left}%`, top: `${p.top}%`,
              fontSize: `${p.size}px`,
              '--dx': `${p.dx}px`,
              '--dy': `${p.dy}vh`,
              '--dy2': `${p.dy2}vh`,
              '--s': p.s,
              '--max-op': p.maxOp,
              '--dur': `${p.dur}s`,
              '--delay': `${p.delay}s`,
            }}
          >
            {p.ch}
          </span>
        ))}
      </div>
    </>
  );
}

/* ── Navbar ──────────────────────────────────────────────────── */
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'backdrop-blur-md bg-[color-mix(in_srgb,var(--parchment)_85%,transparent)] border-b border-[color-mix(in_srgb,var(--ink)_8%,transparent)]'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-[1280px] mx-auto px-6 md:px-10 h-[72px] flex items-center justify-between">
        <a href="#top" className="flex items-center gap-3">
          <span className="sigil-slow inline-flex">
            <Sigil size={26} />
          </span>
          <span
            className="font-display"
            style={{
              fontWeight: 500,
              letterSpacing: '0.18em',
              fontSize: '1rem',
              color: scrolled ? 'var(--ink)' : 'var(--on-dark)',
              transition: 'color 0.5s ease',
              textShadow: scrolled ? 'none' : '0 1px 12px rgba(26,46,53,0.45)',
            }}
          >
            GRIMOIRE
          </span>
        </a>
        <div
          className="hidden md:flex items-center gap-9 text-sm"
          style={{
            color: scrolled ? 'var(--ink-soft)' : 'rgba(250,243,227,0.9)',
            transition: 'color 0.5s ease',
            textShadow: scrolled ? 'none' : '0 1px 12px rgba(26,46,53,0.45)',
          }}
        >
          <a href="#features" className="hover:text-[var(--gold-warm)] transition-colors">Collection</a>
          <a href="#testimonials" className="hover:text-[var(--gold-warm)] transition-colors">Keepers</a>
          <a href="#pricing" className="hover:text-[var(--gold-warm)] transition-colors">Stay</a>
        </div>
        <a href="#pricing" className="btn-gold !py-2 !px-5 text-sm">Begin</a>
      </div>
    </nav>
  );
}

/* ── Hero ────────────────────────────────────────────────────── */
function Hero() {
  const reduced = usePrefersReducedMotion();
  const headlineWords = useMemo(
    () => [
      { text: 'Some' }, { text: 'things' },
      { br: true },
      { text: 'deserve' }, { text: 'to' },
      { br: true },
      { text: 'last' },
      { text: 'forever.', italic: true, gold: true },
    ],
    []
  );

  // word-by-word reveal via setTimeout
  useEffect(() => {
    if (reduced) {
      document.querySelectorAll('.hero-word').forEach((el) => el.classList.add('in'));
      return;
    }
    const words = document.querySelectorAll('.hero-word');
    words.forEach((w, i) => {
      setTimeout(() => w.classList.add('in'), 200 + i * 150);
    });
  }, [reduced]);

  return (
    <section id="top" className="relative min-h-[115vh] w-full overflow-hidden">
      {/* Video background */}
      <HeroVideo />

      {/* Vignette */}
      <div className="hero-vignette" />

      {/* Ambient layers: orbs, wisps, particles */}
      <HeroAmbient />

      {/* Content */}
      <div className="relative z-10 max-w-[1280px] mx-auto px-6 md:px-10 pt-[140px] md:pt-[160px] pb-24">
        <div className="md:max-w-[58%] hero-text">
          <div
            className="eyebrow inline-flex items-center gap-2 mb-6 reveal-word hero-word"
            style={{ color: 'var(--cloud)' }}
          >
            <span style={{ color: 'var(--gold)' }}>✦</span>
            Your personal grimoire
          </div>

          <h1
            className="font-display leading-[1.0] tracking-[-0.01em] relative"
            style={{
              color: 'var(--on-dark)',
              fontWeight: 400,
              fontSize: 'clamp(3rem, 7vw, 6.5rem)',
            }}
          >
            {headlineWords.map((w, i) => {
              if (w.br) return <br key={i} />;
              // gentle per-word float (varied duration + phase)
              const floatDur = 6 + ((i * 1.3) % 3);
              const floatDelay = 1.1 + ((i * 0.4) % 3);
              const floatAmp = -(4 + ((i * 2.1) % 5));
              return (
                <span
                  key={i}
                  className={`reveal-word hero-word inline-block mr-[0.18em] ${w.gold ? 'hero-word-gold relative' : ''}`}
                  style={{
                    fontStyle: w.italic ? 'italic' : 'normal',
                    color: w.gold ? 'var(--gold)' : 'inherit',
                    fontWeight: w.italic ? 500 : 400,
                    textShadow: w.gold ? '0 2px 28px rgba(232,168,71,0.55), 0 2px 14px rgba(26,46,53,0.35)' : undefined,
                    '--float-dur': `${floatDur}s`,
                    '--float-delay': `${floatDelay}s`,
                    '--float': `${floatAmp}px`,
                  }}
                >
                  {w.text}
                  {/* Sparkles trailing from the gold word */}
                  {w.gold && (
                    <>
                      <span className="spark" style={{ left: '-8%',  top: '-12%', fontSize: '14px', '--dur':'3.2s', '--delay':'0s' }}>✦</span>
                      <span className="spark" style={{ left: '38%',  top: '-22%', fontSize: '10px', '--dur':'2.8s', '--delay':'0.9s' }}>⊹</span>
                      <span className="spark" style={{ left: '92%',  top: '8%',   fontSize: '16px', '--dur':'3.6s', '--delay':'1.6s' }}>✦</span>
                      <span className="spark" style={{ left: '108%', top: '38%',  fontSize: '12px', '--dur':'3s',   '--delay':'2.2s' }}>⊹</span>
                      <span className="spark" style={{ left: '64%',  top: '92%',  fontSize: '13px', '--dur':'2.6s', '--delay':'0.4s' }}>·</span>
                      <span className="spark" style={{ left: '18%',  top: '110%', fontSize: '11px', '--dur':'3.4s', '--delay':'1.2s' }}>✦</span>
                    </>
                  )}
                </span>
              );
            })}
          </h1>

          <p
            className="mt-8 reveal-word hero-word"
            style={{
              maxWidth: '440px',
              color: 'rgba(250,243,227,0.92)',
              fontWeight: 300,
              fontSize: '1.075rem',
              lineHeight: 1.65,
            }}
          >
            Seed phrases. Private keys. Letters to your children.
            The things you'd write on paper and hide under a floorboard
            — now woven into the eternity of Filecoin.
          </p>

          {/* glass pill input */}
          <form
            onSubmit={(e) => e.preventDefault()}
            className="reveal-word hero-word liquid-glass-dark mt-9 flex items-center pl-5 pr-1.5 py-1.5 max-w-[480px]"
            style={{ borderRadius: '999px' }}
          >
            <input
              type="text"
              placeholder="your email or wallet"
              className="flex-1 bg-transparent outline-none text-[var(--on-dark)] placeholder:text-[rgba(250,243,227,0.55)] py-2.5 text-sm font-body"
            />
            <button type="submit" className="btn-gold !py-2 !px-5 text-sm shrink-0">
              Begin <ArrowRight size={14} />
            </button>
          </form>

          <div className="mt-6 reveal-word hero-word flex items-center gap-4 text-xs font-mono uppercase tracking-[0.18em]"
               style={{ color: 'rgba(250,243,227,0.7)' }}>
            <span>encrypted client-side</span>
            <span style={{ color: 'var(--gold)' }}>⊹</span>
            <span>stored on filecoin</span>
            <span style={{ color: 'var(--gold)' }}>⊹</span>
            <span>onchain</span>
          </div>
        </div>
      </div>

      {/* scroll cue */}
      <div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 reveal-word hero-word scroll-cue flex flex-col items-center gap-2"
        style={{ color: 'rgba(250,243,227,0.7)' }}
      >
        <span className="text-[10px] uppercase tracking-[0.3em] font-mono">scroll</span>
        <span className="block w-px h-10 bg-[rgba(250,243,227,0.5)]"></span>
      </div>
    </section>
  );
}

/* ── Section heading helper ──────────────────────────────────── */
function SectionEyebrow({ children }) {
  return (
    <div className="eyebrow inline-flex items-center gap-2 reveal">
      <span style={{ color: 'var(--gold)' }}>✦</span>
      {children}
    </div>
  );
}

function SectionTitle({ children, className = '' }) {
  return (
    <h2
      className={`font-display reveal ${className}`}
      style={{
        color: 'var(--ink)',
        fontWeight: 400,
        fontSize: 'clamp(2.25rem, 4.5vw, 3.75rem)',
        lineHeight: 1.08,
        letterSpacing: '-0.01em',
        textWrap: 'balance',
      }}
    >
      {children}
    </h2>
  );
}

function Italic({ children, color = 'var(--gold-warm)' }) {
  return (
    <em style={{ color, fontStyle: 'italic', fontWeight: 500 }}>{children}</em>
  );
}

/* ── 3 · Problem ─────────────────────────────────────────────── */
function Problem() {
  const cards = [
    {
      icon: <IconFlame />,
      title: 'Paper burns.',
      body: 'Fire, floods, time. The most precious notes outlast nothing.',
    },
    {
      icon: <IconDrive />,
      title: 'Drives fail.',
      body: 'Hard drives die silently. Accounts get locked forever. The cloud is someone else\u2019s computer.',
    },
    {
      icon: <IconCompany />,
      title: 'Companies fade.',
      body: 'Even giants disappear. Custodians vanish. What lives on someone\u2019s server lives on borrowed time.',
    },
  ];
  return (
    <section id="problem" className="relative py-28 md:py-36 px-6 md:px-10">
      <div className="max-w-[1180px] mx-auto">
        <SectionEyebrow>What we lose</SectionEyebrow>
        <SectionTitle className="mt-5 max-w-[18ch]">
          Paper <Italic>burns.</Italic> Drives <Italic>fail.</Italic> Companies <Italic>fade.</Italic>
        </SectionTitle>
        <p className="reveal mt-6 max-w-[60ch] text-[var(--ink-soft)] text-lg leading-relaxed">
          Every safekeeping method we trust is borrowed from something fragile.
          Paper smolders. Disks rot. Custodians close their doors with our keepsakes inside.
        </p>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
          {cards.map((c, i) => (
            <div key={i} className="warm-glass reveal p-7 md:p-9" style={{ transitionDelay: `${i * 0.08}s` }}>
              <div className="mb-5">{c.icon}</div>
              <h3 className="font-display text-2xl text-[var(--ink)]" style={{ fontWeight: 500 }}>
                {c.title}
              </h3>
              <p className="mt-3 text-[var(--ink-soft)] leading-relaxed">{c.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── 4 · Solution ────────────────────────────────────────────── */
function Solution() {
  return (
    <section
      id="solution"
      className="relative py-28 md:py-36 px-6 md:px-10 overflow-hidden"
      style={{
        background:
          'linear-gradient(180deg, var(--parchment) 0%, color-mix(in srgb, var(--sky-soft) 32%, var(--parchment)) 50%, var(--parchment) 100%)',
      }}
    >
      {/* subtle cloud wash */}
      <div
        aria-hidden="true"
        className="absolute inset-0 opacity-50 pointer-events-none"
        style={{
          background:
            'radial-gradient(60% 40% at 20% 30%, rgba(255,255,255,0.55), transparent 60%), radial-gradient(50% 35% at 85% 70%, rgba(255,248,232,0.5), transparent 60%)',
        }}
      />

      <div className="relative max-w-[1180px] mx-auto">
        <SectionEyebrow>A grimoire that lasts</SectionEyebrow>
        <SectionTitle className="mt-5 max-w-[22ch]">
          A grimoire that <Italic>cannot</Italic> be burned, broken, or seized.
        </SectionTitle>

        <div className="mt-16 grid grid-cols-1 lg:grid-cols-2 gap-14 lg:gap-20 items-center">
          {/* Left — prose */}
          <div className="space-y-7 max-w-[52ch]">
            {[
              'Open Grimoire, write what only you should know. Your browser whispers it into AES-256 ciphertext before it ever touches a wire.',
              'The ciphertext drifts onto Filecoin — thousands of independent storage providers, holding cryptographic proof of your fragments every twenty-four hours.',
              'Your CID is anchored onchain through FEVM. The protocol remembers. Your wallet is the only key that turns the lock.',
            ].map((line, i) => (
              <p key={i} className="reveal flex gap-4 text-[var(--ink)] text-lg leading-[1.7]" style={{ transitionDelay: `${i * 0.1}s` }}>
                <span className="text-[var(--gold)] text-xl shrink-0 leading-[1.6]">✦</span>
                <span>{line}</span>
              </p>
            ))}
          </div>

          {/* Right — flow diagram */}
          <div className="reveal">
            <div
              className="warm-glass p-8 md:p-10"
              style={{
                background:
                  'linear-gradient(165deg, rgba(255,255,255,0.7) 0%, rgba(255,248,232,0.45) 100%)',
              }}
            >
              <div className="font-mono text-[10px] uppercase tracking-[0.25em] text-[var(--ink-soft)] mb-6">
                The path of a secret
              </div>

              <div className="flex flex-col gap-7 items-stretch">
                <DiagramStep delay={0} node={<NodeWallet />} label="wallet" sub="signs · derives" />
                <DiagramConnector delay={0.15} label="encrypt · AES-256" />
                <DiagramStep delay={0.3} node={<NodeFilecoin />} label="filecoin" sub="proof every 24h" accent />
                <DiagramConnector delay={0.45} label="cid" />
                <DiagramStep delay={0.6} node={<NodeChain />} label="onchain · FEVM" sub="immutable record" />
              </div>

              <div className="mt-8 pt-5 border-t border-dashed border-[color-mix(in_srgb,var(--ink)_15%,transparent)] flex items-center justify-between font-mono text-[11px] uppercase tracking-[0.2em] text-[var(--ink-soft)]">
                <span>only you hold the key</span>
                <span style={{ color: 'var(--gold-warm)' }}>✦ forever</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function DiagramStep({ node, label, sub, accent, delay = 0 }) {
  return (
    <div className="reveal flex items-center gap-5" style={{ transitionDelay: `${delay}s` }}>
      <BrushNode accent={accent}>{node}</BrushNode>
      <div>
        <div className="font-display text-xl text-[var(--ink)]" style={{ fontWeight: 500 }}>
          {label}
        </div>
        <div className="font-mono text-[11px] uppercase tracking-[0.18em] text-[var(--ink-soft)] mt-0.5">
          {sub}
        </div>
      </div>
    </div>
  );
}

function DiagramConnector({ label, delay = 0 }) {
  return (
    <div className="reveal flex items-center gap-4 pl-7" style={{ transitionDelay: `${delay}s` }}>
      <svg width="2" height="44" viewBox="0 0 2 44" aria-hidden="true">
        <path d="M 1 0 Q 1 22 1 44" stroke="var(--gold-warm)" strokeWidth="1.4" fill="none" strokeDasharray="2 4" strokeLinecap="round"/>
      </svg>
      <div className="font-mono text-[10px] uppercase tracking-[0.22em] text-[var(--gold-warm)]">
        ✦ {label}
      </div>
    </div>
  );
}

/* ── 5 · Features ────────────────────────────────────────────── */
function Features() {
  const features = [
    { icon: <IconSeed />,     name: 'Seed phrases',     body: 'Twelve or twenty-four words, ciphered the moment you commit them.', tag: 'AES-256 · client-side' },
    { icon: <IconKey />,      name: 'Private keys',     body: 'Any chain. Any custody model. Quiet, hidden, retrievable.',         tag: 'any chain · ciphered' },
    { icon: <IconDocument />, name: 'Documents',        body: 'Wills, deeds, certificates. The paper that anchors a life.',       tag: 'files · permanent' },
    { icon: <IconLedger />,   name: 'Wallet ledger',    body: 'A readable inventory of every address you steward.',               tag: 'multichain · readable' },
    { icon: <IconLetter />,   name: 'Letters & wills',  body: 'Time-locked messages that reach the right person at the right moment.', tag: 'programmable · onchain' },
    { icon: <IconNote />,     name: 'Private notes',    body: 'Anything you would rather forget the world than ever forget yourself.', tag: 'text · encrypted' },
  ];
  return (
    <section id="features" className="relative py-28 md:py-36 px-6 md:px-10">
      <div className="max-w-[1180px] mx-auto">
        <SectionEyebrow>The collection</SectionEyebrow>
        <SectionTitle className="mt-5 max-w-[20ch]">
          What you may <Italic>keep</Italic> here.
        </SectionTitle>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f, i) => (
            <div
              key={i}
              className="warm-glass reveal p-7 md:p-8 flex flex-col"
              style={{ transitionDelay: `${(i % 3) * 0.08}s` }}
            >
              <div className="mb-5">{f.icon}</div>
              <h3 className="font-display text-2xl text-[var(--ink)]" style={{ fontWeight: 500 }}>{f.name}</h3>
              <p className="mt-3 text-[var(--ink-soft)] leading-relaxed flex-1">{f.body}</p>
              <div className="mt-6 pt-5 border-t border-dashed border-[color-mix(in_srgb,var(--ink)_12%,transparent)]">
                <span className="tag-mono">{f.tag}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── 6 · Science / Trust ─────────────────────────────────────── */
function Science() {
  const proofLines = [
    { k: 'wallet',  v: '0x4a9f...3b7c' },
    { k: 'encrypt', v: 'AES-256 · client-side' },
    { k: 'cid',     v: 'bafybeig7xv...k3m9p2' },
    { k: 'proof',   v: 'PoSt verified · block #4,291,847' },
    { k: 'status',  v: '✦ stored · onchain · forever', gold: true },
  ];
  return (
    <section id="science" className="relative py-28 md:py-36 px-6 md:px-10 overflow-hidden">
      {/* sky strip accent */}
      <div
        aria-hidden="true"
        className="absolute left-0 right-0 top-1/3 bottom-1/3"
        style={{
          background: 'linear-gradient(180deg, transparent, color-mix(in srgb, var(--sky-soft) 28%, transparent), transparent)',
          filter: 'blur(40px)',
        }}
      />

      <div className="relative max-w-[1180px] mx-auto">
        <SectionEyebrow>How the magic works</SectionEyebrow>
        <SectionTitle className="mt-5 max-w-[22ch]">
          How the <Italic>magic</Italic> works.{' '}
          <span style={{ color: 'var(--ink-soft)', fontStyle: 'italic' }}>(It&rsquo;s math.)</span>
        </SectionTitle>

        <div className="mt-16 grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          {/* Prose */}
          <div className="space-y-9 max-w-[50ch]">
            {[
              { title: 'Encrypted in your browser.', body: 'AES-256, client-side. Your secrets become ciphertext on your own machine before anything touches the network.' },
              { title: 'Stored on Filecoin.',         body: 'Cryptographic proofs every twenty-four hours quietly confirm that your data still exists, intact, across thousands of storage providers.' },
              { title: 'Anchored onchain.',           body: 'A smart contract on FEVM remembers your CID — the address of your encrypted parcel. Your wallet is the only key.' },
            ].map((p, i) => (
              <div key={i} className="reveal" style={{ transitionDelay: `${i * 0.1}s` }}>
                <h3 className="font-display text-2xl text-[var(--ink)]" style={{ fontWeight: 500 }}>
                  <span style={{ color: 'var(--gold)', marginRight: '0.5rem' }}>✦</span>
                  {p.title}
                </h3>
                <p className="mt-2 ml-7 text-[var(--ink-soft)] text-lg leading-relaxed">{p.body}</p>
              </div>
            ))}
          </div>

          {/* Terminal */}
          <div className="reveal">
            <div
              className="warm-glass p-7 md:p-9"
              style={{
                background:
                  'linear-gradient(160deg, rgba(255,255,255,0.78) 0%, rgba(244,229,194,0.42) 100%)',
              }}
            >
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ background: 'var(--gold)' }}></span>
                  <span className="w-2.5 h-2.5 rounded-full" style={{ background: 'var(--sky-mid)' }}></span>
                  <span className="w-2.5 h-2.5 rounded-full" style={{ background: 'var(--grass)' }}></span>
                </div>
                <div className="font-mono text-[10px] uppercase tracking-[0.22em] text-[var(--ink-soft)]">
                  inscription · live
                </div>
              </div>

              <div className="">
                {proofLines.map((l, i) => (
                  <div
                    key={i}
                    className="proof-line reveal"
                    style={{ transitionDelay: `${i * 0.3}s` }}
                  >
                    <span className="proof-key">{l.k}</span>
                    <span
                      className="proof-val"
                      style={l.gold ? { color: 'var(--gold-warm)' } : undefined}
                    >
                      → {l.v}
                    </span>
                  </div>
                ))}
              </div>

              <div className="mt-6 flex items-center gap-2 font-mono text-[11px] text-[var(--ink-soft)]">
                <span className="inline-block w-2 h-2 rounded-full animate-pulse" style={{ background: 'var(--grass)' }}></span>
                synced · 14 sec ago
              </div>
            </div>
          </div>
        </div>

        {/* logo strip */}
        <div className="mt-20 reveal">
          <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-[var(--ink-soft)] text-center mb-5 opacity-70">
            woven from
          </div>
          <div className="flex flex-wrap items-center justify-center gap-x-10 md:gap-x-16 gap-y-4">
            {['Filecoin', 'IPFS', 'Lighthouse', 'FEVM'].map((name, i, arr) => (
              <React.Fragment key={name}>
                <span className="logo-strip-item">{name}</span>
                {i < arr.length - 1 && (
                  <span className="text-[var(--gold)] opacity-50">⊹</span>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ── 7 · Testimonials ────────────────────────────────────────── */
function Testimonials() {
  const quotes = [
    { q: 'I sleep better knowing my seed isn\u2019t a piece of paper my kid might find in a drawer.', a: '@nightkeeper' },
    { q: 'I wrote a letter to my daughter she\u2019ll read after I\u2019m gone. Grimoire makes sure she will.', a: '@cipher.eth' },
    { q: 'Inheritance for crypto, finally done right. Not a service. A protocol.', a: '@order_of_keys' },
  ];
  return (
    <section
      id="testimonials"
      className="relative py-28 md:py-36 px-6 md:px-10"
      style={{
        background:
          'linear-gradient(180deg, var(--parchment) 0%, color-mix(in srgb, var(--sky-soft) 28%, var(--parchment)) 50%, var(--parchment) 100%)',
      }}
    >
      <div className="max-w-[1180px] mx-auto">
        <SectionEyebrow>From the keepers</SectionEyebrow>
        <SectionTitle className="mt-5 max-w-[20ch]">
          Quiet voices, <Italic>kept</Italic> safely.
        </SectionTitle>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
          {quotes.map((q, i) => (
            <figure
              key={i}
              className="warm-glass reveal p-8 md:p-9 flex flex-col"
              style={{ transitionDelay: `${i * 0.08}s` }}
            >
              <div className="text-[var(--gold)] text-2xl mb-4 font-display leading-none">&ldquo;</div>
              <blockquote
                className="font-display italic text-[var(--ink)] flex-1"
                style={{ fontSize: 'clamp(1.15rem, 1.4vw, 1.4rem)', lineHeight: 1.45, fontWeight: 400 }}
              >
                {q.q}
              </blockquote>
              <figcaption className="mt-7 pt-5 border-t border-dashed border-[color-mix(in_srgb,var(--ink)_12%,transparent)] font-mono text-[11px] uppercase tracking-[0.18em] text-[var(--ink-soft)]">
                — {q.a}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── 8 · Pricing ─────────────────────────────────────────────── */
function Pricing() {
  const tiers = [
    {
      name: 'The Apprentice',
      price: 'Free',
      sub: 'a quiet beginning',
      features: [
        'Up to 10 inscriptions',
        'AES-256 client-side encryption',
        'Standard Filecoin storage',
        'Annual renewal',
        'Community support',
      ],
      cta: 'Begin freely',
      highlight: false,
    },
    {
      name: 'The Keeper',
      price: '$12',
      priceSub: '/ month',
      altPrice: 'or 100 FIL / year',
      sub: 'for what truly matters',
      features: [
        'Unlimited inscriptions',
        'Programmable inheritance (dead-man\u2019s switch on FEVM)',
        'Priority retrieval network',
        'Multi-signature heir configuration',
        'Direct guidance from the Keepers',
      ],
      cta: 'Take the path',
      highlight: true,
    },
  ];
  return (
    <section id="pricing" className="relative py-28 md:py-36 px-6 md:px-10">
      <div className="max-w-[1180px] mx-auto">
        <SectionEyebrow>Two paths</SectionEyebrow>
        <SectionTitle className="mt-5 max-w-[20ch]">
          Two ways to <Italic>begin</Italic>.
        </SectionTitle>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-7">
          {tiers.map((t, i) => (
            <div
              key={i}
              className={`warm-glass reveal p-9 md:p-11 ${t.highlight ? 'pricing-highlight' : ''}`}
              style={{ transitionDelay: `${i * 0.1}s`, background: t.highlight ? 'linear-gradient(170deg, rgba(255,248,232,0.85), rgba(255,255,255,0.55))' : undefined }}
            >
              {t.highlight && (
                <div className="absolute -top-3 left-9 px-3 py-1 rounded-full font-mono text-[10px] uppercase tracking-[0.22em]"
                     style={{ background: 'var(--gold)', color: 'var(--parchment)' }}>
                  ✦ recommended
                </div>
              )}
              <div className="font-mono text-[11px] uppercase tracking-[0.22em] text-[var(--ink-soft)]">
                {t.sub}
              </div>
              <h3 className="mt-2 font-display text-3xl md:text-4xl text-[var(--ink)]" style={{ fontWeight: 500 }}>
                {t.name}
              </h3>
              <div className="mt-5 flex items-baseline gap-2">
                <span className="font-display text-5xl" style={{ color: t.highlight ? 'var(--gold-warm)' : 'var(--ink)', fontWeight: 400 }}>
                  {t.price}
                </span>
                {t.priceSub && (
                  <span className="text-[var(--ink-soft)] text-lg">{t.priceSub}</span>
                )}
              </div>
              {t.altPrice && (
                <div className="mt-1 font-mono text-[11px] uppercase tracking-[0.18em] text-[var(--ink-soft)]">
                  {t.altPrice}
                </div>
              )}

              <ul className="mt-8 space-y-3.5">
                {t.features.map((f, fi) => (
                  <li key={fi} className="flex gap-3 text-[var(--ink)] leading-relaxed">
                    <span className="text-[var(--gold)] shrink-0 mt-0.5">✦</span>
                    <span>{f}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-9">
                {t.highlight ? (
                  <a href="#" className="btn-gold w-full justify-center">{t.cta} <ArrowRight size={14} /></a>
                ) : (
                  <a href="#" className="btn-ghost w-full justify-center">{t.cta} <ArrowRight size={14} /></a>
                )}
              </div>
            </div>
          ))}
        </div>

        <p className="reveal mt-12 text-center font-mono text-xs uppercase tracking-[0.22em] text-[var(--ink-soft)]">
          Pay in FIL, USDC, or any card. <span style={{ color: 'var(--gold-warm)' }}>No KYC. Ever.</span>
        </p>
      </div>
    </section>
  );
}

/* ── 9 · Footer ──────────────────────────────────────────────── */
function Footer() {
  const cols = [
    {
      title: 'The Collection',
      links: ['Open Grimoire', 'What to Keep', 'Inheritance', 'Heir Settings', 'Recovery Guide'],
    },
    {
      title: 'The Keepers',
      links: ['Manifesto', 'The Council', 'Field Notes', 'Join Us'],
    },
    {
      title: 'Help',
      links: ['Reach Us', 'Privacy', 'Terms', 'Report an Issue'],
    },
  ];
  return (
    <footer
      className="reveal liquid-glass w-full rounded-3xl p-6 md:p-10 text-[var(--ink-soft)] mt-24 md:mt-40 mx-4 md:mx-8 mb-8"
      style={{
        background:
          'linear-gradient(170deg, rgba(255,255,255,0.55) 0%, rgba(168,208,216,0.28) 100%)',
      }}
    >
      {/* Top grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-10 md:gap-12 mb-10">
        {/* Left brand */}
        <div className="md:col-span-5">
          <div className="flex items-center gap-3 mb-4">
            <Sigil size={26} />
            <span
              className="font-display text-xl"
              style={{ fontWeight: 500, color: 'var(--ink)', letterSpacing: '0.12em' }}
            >
              GRIMOIRE
            </span>
          </div>
          <p className="text-sm leading-relaxed max-w-sm text-[var(--ink-soft)]">
            A quiet vault for the things that matter most — encrypted by you,
            stored on Filecoin, kept safe forever.
          </p>
        </div>

        {/* Right cols */}
        <div className="md:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-8">
          {cols.map((col) => (
            <div key={col.title}>
              <div className="text-sm uppercase tracking-wider text-[var(--ink)] font-medium mb-4">
                {col.title}
              </div>
              <ul className="space-y-2.5">
                {col.links.map((l) => (
                  <li key={l}>
                    <a href="#" className="text-sm text-[var(--ink-soft)] hover:text-[var(--gold-warm)] transition-colors">
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom bar */}
      <div className="pt-6 border-t border-[color-mix(in_srgb,var(--ink)_10%,transparent)] flex flex-col md:flex-row items-center justify-between gap-6 md:gap-4">
        <p className="text-[10px] uppercase tracking-widest opacity-50">
          Made with care · © 2026 The Grimoire Order
        </p>
        <div className="flex items-center gap-4">
          <span className="text-[10px] uppercase tracking-widest opacity-50">Stay in touch:</span>
          <div className="flex items-center gap-3">
            {[Twitter, Github, MessageCircle, Send, Mail].map((Ico, i) => (
              <a
                key={i}
                href="#"
                className="opacity-60 hover:opacity-100 transition-colors hover:text-[var(--gold)]"
              >
                <Ico size={16} />
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, {
  Navbar, Hero, Problem, Solution, Features, Science, Testimonials, Pricing, Footer,
  usePrefersReducedMotion, useReveal,
});
